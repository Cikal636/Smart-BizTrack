package com.example.smartbiztrack

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "smart_biztrack.db"
        private const val DATABASE_VERSION = 2 // Naikkan versi karena ada penambahan tabel user

        // --- TABEL BARANG ---
        const val TABLE_BARANG = "tbl_barang"
        const val COL_BARANG_ID = "id"
        const val COL_KODE = "kode"
        const val COL_NAMA_BARANG = "nama_barang"
        const val COL_STOK = "stok"
        const val COL_HARGA_BELI = "harga_beli"
        const val COL_HARGA_JUAL = "harga_jual"

        // --- TABEL KEUANGAN ---
        const val TABLE_KEUANGAN = "tbl_keuangan"
        const val COL_KEUANGAN_ID = "id"
        const val COL_TANGGAL = "tanggal"
        const val COL_JENIS = "jenis"
        const val COL_JUMLAH = "jumlah"
        const val COL_KETERANGAN = "keterangan"

        // --- TABEL USER (LOGIN & SIGN UP) ---
        const val TABLE_USER = "tbl_user"
        const val COL_USER_ID = "id"
        const val COL_EMAIL = "email"
        const val COL_PASSWORD = "password"
        const val COL_NAMA_LENGKAP = "nama_lengkap"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTableBarang = ("CREATE TABLE $TABLE_BARANG (" +
                "$COL_BARANG_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COL_KODE TEXT, " +
                "$COL_NAMA_BARANG TEXT, " +
                "$COL_STOK INTEGER, " +
                "$COL_HARGA_BELI REAL, " +
                "$COL_HARGA_JUAL REAL)")
        db?.execSQL(createTableBarang)

        val createTableKeuangan = ("CREATE TABLE $TABLE_KEUANGAN (" +
                "$COL_KEUANGAN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COL_TANGGAL TEXT, " +
                "$COL_JENIS TEXT, " +
                "$COL_JUMLAH REAL, " +
                "$COL_KETERANGAN TEXT)")
        db?.execSQL(createTableKeuangan)

        val createTableUser = ("CREATE TABLE $TABLE_USER (" +
                "$COL_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COL_EMAIL TEXT, " +
                "$COL_PASSWORD TEXT, " +
                "$COL_NAMA_LENGKAP TEXT)")
        db?.execSQL(createTableUser)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_BARANG")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_KEUANGAN")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_USER")
        onCreate(db)
    }

    // --- FUNGSI AUTH (SIGN UP & LOGIN) ---
    fun registerUser(email: String, password: String, nama: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COL_EMAIL, email)
            put(COL_PASSWORD, password)
            put(COL_NAMA_LENGKAP, nama)
        }
        val result = db.insert(TABLE_USER, null, values)
        db.close()
        return result != -1L
    }

    fun checkLogin(email: String, password: String): String? {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT $COL_NAMA_LENGKAP FROM $TABLE_USER WHERE $COL_EMAIL = ? AND $COL_PASSWORD = ?", arrayOf(email, password))
        var namaLengkap: String? = null
        if (cursor.moveToFirst()) {
            namaLengkap = cursor.getString(0)
        }
        cursor.close()
        db.close()
        return namaLengkap
    }

    // --- FUNGSI CRUD BARANG ---
    fun tambahBarang(kode: String, nama: String, stok: Int, hargaBeli: Double, hargaJual: Double): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COL_KODE, kode)
            put(COL_NAMA_BARANG, nama)
            put(COL_STOK, stok)
            put(COL_HARGA_BELI, hargaBeli)
            put(COL_HARGA_JUAL, hargaJual)
        }
        val result = db.insert(TABLE_BARANG, null, values)
        db.close()
        return result != -1L
    }

    fun bacaSemuaBarang(): Cursor {
        val db = this.readableDatabase
        return db.rawQuery("SELECT * FROM $TABLE_BARANG ORDER BY $COL_BARANG_ID DESC", null)
    }

    fun updateBarang(id: String, kode: String, nama: String, stok: Int, hargaBeli: Double, hargaJual: Double): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COL_KODE, kode)
            put(COL_NAMA_BARANG, nama)
            put(COL_STOK, stok)
            put(COL_HARGA_BELI, hargaBeli)
            put(COL_HARGA_JUAL, hargaJual)
        }
        val result = db.update(TABLE_BARANG, values, "$COL_BARANG_ID = ?", arrayOf(id))
        db.close()
        return result > 0
    }

    fun hapusBarang(id: String): Int {
        val db = this.writableDatabase
        val result = db.delete(TABLE_BARANG, "$COL_BARANG_ID = ?", arrayOf(id))
        db.close()
        return result
    }

    fun hitungTotalAset(): Double {
        val db = this.readableDatabase
        var totalAset = 0.0
        val cursor = db.rawQuery("SELECT SUM(stok * harga_beli) FROM $TABLE_BARANG", null)

        if (cursor.moveToFirst()) {
            if (!cursor.isNull(0)) {
                totalAset = cursor.getDouble(0)
            }
        }
        cursor.close()
        return totalAset
    }
}