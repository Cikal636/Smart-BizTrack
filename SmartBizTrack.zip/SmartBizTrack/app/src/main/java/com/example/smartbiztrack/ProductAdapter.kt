package com.example.smartbiztrack

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import java.text.NumberFormat
import java.util.Locale

data class ProductModel(
    val id: String,
    val kode: String,
    val nama: String,
    val stok: Int,
    val hargaBeli: Double,
    val hargaJual: Double
)

class ProductAdapter(private val context: Context, private var productList: ArrayList<ProductModel>) : BaseAdapter() {

    override fun getCount(): Int = productList.size

    override fun getItem(position: Int): Any = productList[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_product, parent, false)

        val product = productList[position]

        val tvNama = view.findViewById<TextView>(R.id.tvNamaProduk)
        val tvSku = view.findViewById<TextView>(R.id.tvSku)
        val tvStok = view.findViewById<TextView>(R.id.tvStok)
        val tvHargaBeli = view.findViewById<TextView>(R.id.tvHargaBeli)
        val tvHargaJual = view.findViewById<TextView>(R.id.tvHargaJual)

        val formatRupiah = NumberFormat.getNumberInstance(Locale("in", "ID"))

        tvNama.text = product.nama
        tvSku.text = "SKU: ${product.kode}"
        tvStok.text = "Stok: ${product.stok} Unit"
        tvHargaBeli.text = "Modal: Rp ${formatRupiah.format(product.hargaBeli)}"
        tvHargaJual.text = "Rp ${formatRupiah.format(product.hargaJual)}"

        return view
    }

    // Fungsi khusus untuk menyaring data saat fitur Search diketik
    fun updateData(newProductList: ArrayList<ProductModel>) {
        productList = newProductList
        notifyDataSetChanged()
    }
}