package com.example.smartbiztrack

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import com.example.smartbiztrack.databinding.ActivityMainBinding
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = DatabaseHelper(this)
        updateTotalAset()

        // Tombol Simpan Data ke SQLite
        binding.btnSimpanBarang.setOnClickListener {
            val kode = binding.etKode.text.toString().trim()
            val nama = binding.etNamaBarang.text.toString().trim()
            val stokStr = binding.etStok.text.toString().trim()
            val hargaBeliStr = binding.etHargaBeli.text.toString().trim()
            val hargaJualStr = binding.etHargaJual.text.toString().trim()

            if (kode.isEmpty() || nama.isEmpty() || stokStr.isEmpty() || hargaBeliStr.isEmpty() || hargaJualStr.isEmpty()) {
                Toast.makeText(this, "Semua kolom wajib diisi!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val isSuccess = dbHelper.tambahBarang(
                kode,
                nama,
                stokStr.toInt(),
                hargaBeliStr.toDouble(),
                hargaJualStr.toDouble()
            )

            if (isSuccess) {
                Toast.makeText(this, "Produk berhasil disimpan!", Toast.LENGTH_SHORT).show()
                binding.etKode.text.clear()
                binding.etNamaBarang.text.clear()
                binding.etStok.text.clear()
                binding.etHargaBeli.text.clear()
                binding.etHargaJual.text.clear()
                updateTotalAset()
            } else {
                Toast.makeText(this, "Gagal menyimpan produk", Toast.LENGTH_SHORT).show()
            }
        }

        // Tombol Pindah ke Halaman Lihat Data
        binding.btnLihatData.setOnClickListener {
            startActivity(Intent(this, DataActivity::class.java))
        }

        // --- ICON MENU POPUP (Setting, About, Logout) ---
        binding.btnMenu.setOnClickListener { view ->
            val popup = PopupMenu(this, view)
            popup.menu.add("Setting")
            popup.menu.add("About App")
            popup.menu.add("Logout")

            popup.setOnMenuItemClickListener { item: MenuItem ->
                when (item.title) {
                    "Setting" -> {
                        startActivity(Intent(this, SettingActivity::class.java))
                        true
                    }
                    "About App" -> {
                        startActivity(Intent(this, AboutActivity::class.java))
                        true
                    }
                    "Logout" -> {
                        prosesLogout()
                        true
                    }
                    else -> false
                }
            }
            popup.show()
        }
    }

    private fun prosesLogout() {
        AlertDialog.Builder(this)
            .setTitle("Keluar Akun")
            .setMessage("Apakah kamu yakin ingin keluar dari sesi ini?")
            .setPositiveButton("Ya, Keluar") { _, _ ->
                val sharedPref = getSharedPreferences("SmartBizSession", Context.MODE_PRIVATE)
                sharedPref.edit().clear().apply()

                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun updateTotalAset() {
        val total = dbHelper.hitungTotalAset()
        val formatRupiah = NumberFormat.getNumberInstance(Locale("in", "ID")).format(total)
        binding.tvTotalBalance.text = "Rp $formatRupiah"
    }

    override fun onResume() {
        super.onResume()
        updateTotalAset()
    }
}