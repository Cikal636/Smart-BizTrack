package com.example.smartbiztrack

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.smartbiztrack.databinding.ActivitySettingBinding

class SettingActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingBinding
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = DatabaseHelper(this)

        binding.btnKembaliSetting.setOnClickListener {
            finish()
        }

        // Fitur opsional: Reset database barang
        binding.tvHapusSemuaData.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Peringatan Reset Data")
                .setMessage("Apakah Anda yakin ingin menghapus seluruh data produk yang tersimpan di gudang?")
                .setPositiveButton("Ya, Hapus Semua") { _, _ ->
                    val db = dbHelper.writableDatabase
                    db.execSQL("DELETE FROM ${DatabaseHelper.TABLE_BARANG}")
                    Toast.makeText(this, "Semua data produk berhasil dikosongkan.", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Batal", null)
                .show()
        }
    }
}