package com.example.smartbiztrack

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.smartbiztrack.databinding.ActivityAboutBinding

class AboutActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnKembaliAbout.setOnClickListener {
            finish()
        }
    }
}