package com.example.smartbiztrack

import android.database.Cursor
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doOnTextChanged
import com.example.smartbiztrack.databinding.ActivityDataBinding
import com.google.android.material.snackbar.Snackbar

class DataActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDataBinding
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var productList: ArrayList<ProductModel>
    private lateinit var adapter: ProductAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDataBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = DatabaseHelper(this)
        productList = ArrayList()

        muatDataKeList()

        // Tombol kembali ke halaman utama
        binding.btnKembali.setOnClickListener {
            finish()
        }

        // --- FITUR SEARCH / PENCARIAN REAL-TIME ---
        binding.etSearch.doOnTextChanged { text, _, _, _ ->
            cariProduk(text.toString())
        }

        // Aksi ketika salah satu item produk di-klik
        binding.listViewSemuaData.setOnItemClickListener { _, _, position, _ ->
            val produk = (binding.listViewSemuaData.adapter as ProductAdapter).getItem(position) as ProductModel

            val options = arrayOf("Edit Produk", "Hapus Produk")
            AlertDialog.Builder(this)
                .setTitle("Pilih Aksi untuk ${produk.nama}")
                .setItems(options) { _, which ->
                    when (which) {
                        0 -> bukaDialogEdit(produk)
                        1 -> hapusDenganUndo(produk, position)
                    }
                }
                .show()
        }
    }

    private fun muatDataKeList() {
        productList.clear()
        val cursor: Cursor = dbHelper.bacaSemuaBarang()

        if (cursor.count > 0) {
            while (cursor.moveToNext()) {
                val id = cursor.getString(0)
                val kode = cursor.getString(1)
                val nama = cursor.getString(2)
                val stok = cursor.getInt(3)
                val hargaBeli = cursor.getDouble(4)
                val hargaJual = cursor.getDouble(5)

                productList.add(ProductModel(id, kode, nama, stok, hargaBeli, hargaJual))
            }
        }
        cursor.close()

        adapter = ProductAdapter(this, productList)
        binding.listViewSemuaData.adapter = adapter
    }

    private fun cariProduk(keyword: String) {
        val filteredList = ArrayList<ProductModel>()
        for (produk in productList) {
            if (produk.nama.contains(keyword, ignoreCase = true) || produk.kode.contains(keyword, ignoreCase = true)) {
                filteredList.add(produk)
            }
        }
        adapter.updateData(filteredList)
    }

    private fun hapusDenganUndo(produk: ProductModel, position: Int) {
        productList.remove(produk)
        adapter.notifyDataSetChanged()

        val handler = Handler(Looper.getMainLooper())
        val pendingDeleteRunnable = Runnable {
            dbHelper.hapusBarang(produk.id)
        }
        handler.postDelayed(pendingDeleteRunnable, 4000)

        Snackbar.make(binding.root, "${produk.nama} dihapus", Snackbar.LENGTH_LONG)
            .setAction("UNDO") {
                handler.removeCallbacks(pendingDeleteRunnable)
                productList.add(position, produk)
                adapter.notifyDataSetChanged()
                Toast.makeText(this, "Penghapusan dibatalkan", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun bukaDialogEdit(produk: ProductModel) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_product, null)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        val etKode = dialogView.findViewById<EditText>(R.id.etEditKode)
        val etNama = dialogView.findViewById<EditText>(R.id.etEditNama)
        val etStok = dialogView.findViewById<EditText>(R.id.etEditStok)
        val etHargaBeli = dialogView.findViewById<EditText>(R.id.etEditHargaBeli)
        val etHargaJual = dialogView.findViewById<EditText>(R.id.etEditHargaJual)
        val btnBatal = dialogView.findViewById<Button>(R.id.btnBatalEdit)
        val btnSimpan = dialogView.findViewById<Button>(R.id.btnSimpanEdit)

        etKode.setText(produk.kode)
        etNama.setText(produk.nama)
        etStok.setText(produk.stok.toString())
        etHargaBeli.setText(produk.hargaBeli.toString())
        etHargaJual.setText(produk.hargaJual.toString())

        btnBatal.setOnClickListener { dialog.dismiss() }

        btnSimpan.setOnClickListener {
            val kodeBaru = etKode.text.toString().trim()
            val namaBaru = etNama.text.toString().trim()
            val stokBaru = etStok.text.toString().toIntOrNull() ?: 0
            val beliBaru = etHargaBeli.text.toString().toDoubleOrNull() ?: 0.0
            val jualBaru = etHargaJual.text.toString().toDoubleOrNull() ?: 0.0

            if (kodeBaru.isEmpty() || namaBaru.isEmpty()) {
                Toast.makeText(this, "Kolom tidak boleh kosong!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val sukses = dbHelper.updateBarang(produk.id, kodeBaru, namaBaru, stokBaru, beliBaru, jualBaru)
            if (sukses) {
                Toast.makeText(this, "Produk berhasil diperbarui!", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                muatDataKeList()
            } else {
                Toast.makeText(this, "Gagal memperbarui produk", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }
}